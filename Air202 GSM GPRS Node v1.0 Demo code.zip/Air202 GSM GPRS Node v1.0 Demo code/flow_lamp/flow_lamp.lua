--- 模块功能：GPIO功能测试.
-- @author openLuat
-- @module gpio.testGpioSingle
-- @license MIT
-- @copyright openLuat
-- @release 2018.03.27

module(...,package.seeall)

require"pins"

--[[
重要提醒!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

使用某些GPIO时，必须在脚本中写代码打开GPIO所属的电压域，配置电压输出输入等级，这些GPIO才能正常工作
必须在GPIO使用前(即调用pins.setup前)调用pmd.ldoset(电压等级,电压域类型)
电压等级与对应的电压如下：
0--关闭
1--1.8V
2--1.9V
3--2.0V
4--2.6V
5--2.8V
6--3.0V
7--3.3V
IO配置为输出时，高电平时的输出电压即为配置的电压等级对应的电压
IO配置为输入或者中断时，外设输入的高电平电压必须与配置的电压等级的电压匹配

电压域与控制的GPIO的对应关系如下：
pmd.LDO_VMMC：GPIO8、GPIO9、GPIO10、GPIO11、GPIO12、GPIO13
pmd.LDO_VLCD：GPIO14、GPIO15、GPIO16、GPIO17、GPIO18
pmd.LDO_VCAM：GPIO19、GPIO20、GPIO21、GPIO22、GPIO23、GPIO24
一旦设置了某一个电压域的电压等级，受该电压域控制的所有GPIO的高电平都与设置的电压等级一致

例如：GPIO8输出电平时，要求输出2.8V，则调用pmd.ldoset(5,pmd.LDO_VMMC)
]]

local flow, tmp = {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 0
pmd.ldoset(5, pmd.LDO_VMMC)   
local ledpin1 = pins.setup(pio.P0_8, 0)
local ledpin2 = pins.setup(pio.P0_11, 0)
local ledpin3 = pins.setup(pio.P0_3, 0)
local ledpin4 = pins.setup(pio.P0_12, 0)
local ledpin5 = pins.setup(pio.P0_10, 0)	
local ledpin6 = pins.setup(pio.P0_5, 0)	

local ledpin7 = pins.setup(pio.P0_7, 0)	
local ledpin8 = pins.setup(pio.P0_6, 0)	
local ledpin9 = pins.setup(pio.P0_2, 0)	
local ledpin10 = pins.setup(pio.P0_4, 0)	
local ledpin11 = pins.setup(pio.P0_29, 0)	

sys.timerLoopStart(function()
	tmp = table.remove(flow)
	table.insert(flow, 1, tmp)
	ledpin1(flow[1])
	ledpin2(flow[2])
	ledpin3(flow[3])
	ledpin4(flow[4])
	ledpin5(flow[5])
	ledpin6(flow[6])
	ledpin7(flow[7])
	ledpin8(flow[8])
	ledpin9(flow[9])
	ledpin10(flow[10])
	ledpin11(flow[11])	
end,100)



