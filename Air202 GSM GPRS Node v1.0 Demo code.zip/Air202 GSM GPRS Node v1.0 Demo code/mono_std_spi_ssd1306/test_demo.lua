--- module test：SPI SSD1306 test.
-- @author openLuat
-- @module mono_std_spi_ssd1306
-- @license MIT
-- @copyright openLuat
-- @release 2018.03.27

module(...,package.seeall)

require 'misc'
require "common"
require "sim"
require "mono_std_spi_ssd1306"

-- Gets the initial X coordinates of the string display.
local function getxpos(width, str)
    return (width - string.len(str) * 8) / 2
end

function uiDemo(str, str2, str3, str4)
    local WIDTH, HEIGHT = 128,64
    disp.clear()
	disp.puttext(common.utf8ToGb2312(str), getxpos(WIDTH, common.utf8ToGb2312(str)), 0)
	if str2 ~= nil then disp.puttext(common.utf8ToGb2312(str2), getxpos(WIDTH, common.utf8ToGb2312(str2)), 16) end
	if str3 ~= nil then disp.puttext(common.utf8ToGb2312(str3), getxpos(WIDTH, common.utf8ToGb2312(str3)), 32) end
	if str4 ~= nil then disp.puttext(common.utf8ToGb2312(str4), getxpos(WIDTH, common.utf8ToGb2312(str4)), 48) end
    --Refresh the LCD display buffer to the LCD screen
    disp.update()
end

sys.taskInit(function()
	mono_std_spi_ssd1306.init(0xFFFF)	
    while true do
		log.info("------spi_ssd1306 code running-------")

		local ccid = sim.getIccid()
		if ccid == nil then
			ccid = 0
			log.info("------ccid nil-------")
		end
		
		local c = misc.getClock()
		local date = string.format('%02d:%02d:%02d', c.hour, c.min, c.sec)
		
		uiDemo("LuatBoard-Air202",date, "ccid: "..ccid)	
		sys.wait(1000)
    end
end)

